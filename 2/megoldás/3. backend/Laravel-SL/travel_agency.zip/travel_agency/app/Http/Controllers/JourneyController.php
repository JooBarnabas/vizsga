<?php

namespace App\Http\Controllers;

use App\Models\Journey;
use App\Models\Vehicle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use PhpParser\Node\Stmt\TryCatch;

class JourneyController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
        [
            'vehicle' => 'required',
            'country' => 'required',
            'description' => 'required',
            'departure' => 'required'
        ]);

        if ($validator->fails())
        {
            return response()->json(['message' => 'Hiányos adatok'],400);
        }
        $journey = Journey::create($request->all());
        return response()->json(['id' => $journey->id],201);
    }

    public function searchByVehicle($vehicle)
    {
        $journeys = Journey::with('vehicle')->where('vehicle',$vehicle)->get();
        if ($journeys->count() == 0)
        {
            return response()->json(['message' => 'A megadott járművel nem érhető el utazási ajánlat.'],404);
        }
        return $journeys;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Journey  $journey
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $journey = Journey::findOrFail($id);
            $journey->delete();
            return response('',204);
        } catch (\Throwable $th) {
            return response()->json(['message' => 'Az ajánlat nem létezik.'],404);
        }
    }
}
