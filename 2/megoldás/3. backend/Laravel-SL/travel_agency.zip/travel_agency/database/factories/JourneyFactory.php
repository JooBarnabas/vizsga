<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Journey>
 */
class JourneyFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'vehicle' => rand(1,5),
            'country' => $this->faker->country,
            'description' => $this->faker->sentence(12),
            'departure' => $this->faker->date,
            'capacity' => rand(1,100),
            'pictureUrl' => $this->faker->url()
        ];
    }
}
